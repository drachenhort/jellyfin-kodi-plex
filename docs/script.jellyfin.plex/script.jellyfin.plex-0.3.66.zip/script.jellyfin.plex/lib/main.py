"""App bootstrap and window navigation.

Each window's open() blocks (via doModal()) until it closes, so the natural
way to build a "stack" of screens — where Back returns to the previous
screen instead of exiting the addon — is nested loops: showing a screen
again after a deeper screen closes with no result (Back) is just looping;
moving to a deeper screen is just a nested function call. Only backing out
of the root Home loop actually ends the script.
"""

import uuid

import requests
import xbmc
import xbmcaddon
import xbmcgui

from lib import player, servers
from lib.jellyfin import JellyfinClient, auth, library, system
from lib.jellyfin import client as client_mod
from lib.windows.browse import BrowseWindow
from lib.windows.detail import DetailWindow
from lib.windows.home import HomeWindow
from lib.windows.kodigui import (
    HOME_WINDOW_ID,
    LOG_PREFIX,
    RUNNING_PROPERTY,
    STOP_REQUESTED_PROPERTY,
    ScriptStopRequested,
)
from lib.windows.login import LoginWindow
from lib.windows.next_episode import NextEpisodeWindow
from lib.windows.search import SearchWindow
from lib.windows.servers import ServerListWindow

ADDON = xbmcaddon.Addon()
ADDON_PATH = ADDON.getAddonInfo("path")
ADDON_VERSION = ADDON.getAddonInfo("version")

# RUNNING_PROPERTY/STOP_REQUESTED_PROPERTY/HOME_WINDOW_ID and
# ScriptStopRequested live in lib.windows.kodigui (imported above) since
# WindowMixin._watch_abort() needs them too - see that module for the
# single-instance design this implements. Without this guard, a second
# instance starts a second independent window/navigation stack, and
# quitting one leaves the other running underneath, which reads as
# "quitting doesn't work" - Back closes what's on screen but the addon is
# still there. STOP_WAIT_TIMEOUT_SECONDS below is how long a fresh launch
# waits for a previous, possibly-wedged instance to notice
# STOP_REQUESTED_PROPERTY and free the slot on its own before this launch
# just reclaims it - a real device freeze (network stream wedged inside
# Kodi's own player engine, see CHANGELOG v0.3.38) showed a stuck instance
# can otherwise leave every future launch attempt permanently refused with
# "Already running" until Kodi itself is restarted.
STOP_WAIT_TIMEOUT_SECONDS = 5

# Item types that are containers to drill down into rather than play.
CONTAINER_TYPES = {"Series", "Season", "MusicArtist", "MusicAlbum", "BoxSet", "Folder"}


def _get_device_id():
    device_id = ADDON.getSetting("device_id")
    if not device_id:
        device_id = str(uuid.uuid4())
        ADDON.setSetting("device_id", device_id)
    return device_id


def _get_request_timeout():
    """The addon's "Server request timeout" setting, in seconds - falls
    back to JellyfinClient's own default if unset or not a valid int (e.g.
    on first run before the setting has ever been saved)."""
    try:
        return int(ADDON.getSetting("request_timeout_seconds"))
    except (TypeError, ValueError):
        return client_mod.REQUEST_TIMEOUT_SECONDS


def _load_servers():
    return servers.deserialize(ADDON.getSetting("servers"))


def _save_servers(server_list):
    ADDON.setSetting("servers", servers.serialize(server_list))


def _get_active_server_id():
    return ADDON.getSetting("active_server_id")


def _set_active_server_id(server_id):
    ADDON.setSetting("active_server_id", server_id)


def _client_from_server(server):
    client = JellyfinClient(
        server.get("server_url", ""), _get_device_id(), client_version=ADDON_VERSION,
        request_timeout=_get_request_timeout(),
    )
    client.access_token = server.get("access_token")
    client.user_id = server.get("user_id")
    return client


def _probe_server(server):
    """Lightweight reachability check for a saved server: hits the
    unauthenticated /System/Info/Public endpoint so a connection problem
    (server down, network unreachable, 5xx) is caught here rather than
    surfacing later as a broken Home screen. Returns (client, None) on
    success, or (None, short_reason) on failure - never raises."""
    client = _client_from_server(server)
    try:
        system.get_public_info(client)
    except (client_mod.JellyfinApiError, requests.exceptions.RequestException) as exc:
        return None, str(exc)[:200]
    return client, None


def _load_saved_client():
    """Connects to the active saved server, falling back to another saved
    server (in list order) if the active one can't be reached - e.g. its
    Jellyfin instance is down or returning 5xx. The user is always notified
    when this happens, and why, so a switched-to library doesn't look like
    it appeared out of nowhere."""
    server_list = _load_servers()
    if not server_list:
        return None
    active_id = _get_active_server_id()
    active_server = servers.find(server_list, active_id)
    if not active_server:
        active_server = server_list[0]
        _set_active_server_id(active_server["id"])

    client, error = _probe_server(active_server)
    if client is not None:
        return client if client.is_authenticated() else None

    xbmc.log(
        f"{LOG_PREFIX} Active server '{active_server.get('name')}' unreachable "
        f"({error}) - trying other saved servers",
        xbmc.LOGWARNING,
    )
    for server in server_list:
        if server["id"] == active_server["id"]:
            continue
        fallback_client, fallback_error = _probe_server(server)
        if fallback_client is None or not fallback_client.is_authenticated():
            continue
        _set_active_server_id(server["id"])
        xbmcgui.Dialog().notification(
            "Jellyfin",
            f"'{active_server.get('name')}' unreachable ({error}) - "
            f"switched to '{server.get('name')}'",
        )
        return fallback_client

    xbmcgui.Dialog().notification(
        "Jellyfin", f"'{active_server.get('name')}' unreachable: {error}"
    )
    return None


def _migrate_legacy_settings():
    """One-time best-effort carry-over from the pre-multi-server single
    server_url/access_token/user_id settings, so an existing install doesn't
    get logged out by this update. Never raises: a failed migration just
    means one re-login, not data loss."""
    try:
        if ADDON.getSetting("servers"):
            return
        server_url = ADDON.getSetting("server_url")
        access_token = ADDON.getSetting("access_token")
        user_id = ADDON.getSetting("user_id")
        if not (server_url and access_token and user_id):
            return
        server_list, server_id = servers.upsert([], {
            "name": server_url,
            "server_url": server_url,
            "access_token": access_token,
            "user_id": user_id,
        })
        _save_servers(server_list)
        _set_active_server_id(server_id)
    except Exception:  # noqa: BLE001 - best-effort, never block startup
        pass


def _server_name(client):
    try:
        info = system.get_public_info(client)
        return (info or {}).get("ServerName") or client.server_url
    except Exception:  # noqa: BLE001 - name is cosmetic, never fail login over it
        return client.server_url


def _login():
    result = LoginWindow.open(
        ADDON_PATH,
        default_server_url="",
        device_id=_get_device_id(),
        client_version=ADDON_VERSION,
    )
    if not result:
        return None
    client = JellyfinClient(
        result["server_url"], result["device_id"], client_version=ADDON_VERSION,
        request_timeout=_get_request_timeout(),
    )
    client.access_token = result["access_token"]
    client.user_id = result["user_id"]

    server_list, server_id = servers.upsert(_load_servers(), {
        "name": _server_name(client),
        "server_url": client.server_url,
        "access_token": client.access_token,
        "user_id": client.user_id,
    })
    _save_servers(server_list)
    _set_active_server_id(server_id)
    return client


def _manage_servers(client):
    """Home's "Servers" action. Loops the server-management screen, letting
    the user add/remove/switch saved servers. Returns a new client to switch
    to, or None to resume the Home loop unchanged."""
    while True:
        server_list = _load_servers()
        active_id = _get_active_server_id()
        result = ServerListWindow.open(
            ADDON_PATH, servers=server_list, active_id=active_id
        )
        if not result:
            return None
        if result["action"] == "add":
            new_client = _login()
            if new_client is None:
                continue
            return new_client
        elif result["action"] == "remove":
            _save_servers(servers.remove(server_list, result["server_id"]))
            continue
        elif result["action"] == "select":
            if result["server_id"] == active_id:
                return None
            server = servers.find(server_list, result["server_id"])
            if not server:
                continue
            _set_active_server_id(server["id"])
            return _client_from_server(server)


def _offer_next_episode(client, item_id):
    """Called right after an Episode finishes playing to completion (not on
    a manual stop). Offers the next episode in the same season via a
    Plex-style "Up Next" prompt with a 30s auto-play countdown
    (lib/windows/next_episode.py); chains onward through the rest of the
    season for as long as the user keeps letting it auto-play or clicking
    Play Now, and stops silently at the season's last episode, on Cancel/
    Back, or if playback of the next episode doesn't itself end cleanly."""
    try:
        next_item = library.get_next_episode_in_season(client, item_id)
    except Exception as exc:  # noqa: BLE001 - a lookup failure must not crash the addon
        xbmcgui.Dialog().notification("Jellyfin", f"Couldn't check for next episode: {exc}")
        return
    if not next_item:
        return
    try:
        result = NextEpisodeWindow.open(ADDON_PATH, client=client, next_item=next_item)
    except Exception as exc:  # noqa: BLE001 - a window failure must not crash the addon
        xbmcgui.Dialog().notification("Jellyfin", f"Couldn't show next episode prompt: {exc}")
        return
    if not result or result.get("action") != "play":
        return
    next_id = next_item["Id"]
    try:
        status, played_item_id = player.play_item(client, next_id, item_type="Episode")
    except Exception as exc:  # noqa: BLE001 - surface playback failures, don't crash the addon
        xbmcgui.Dialog().notification("Jellyfin", f"Playback failed: {exc}")
        return
    if status == "ended":
        _offer_next_episode(client, played_item_id)


def _detail_loop(client, item_id):
    while True:
        result = DetailWindow.open(ADDON_PATH, client=client, item_id=item_id)
        if not result:
            return
        if result["action"] == "play":
            try:
                status, played_item_id = player.play_item(
                    client,
                    result["item_id"],
                    item_type=result.get("item_type"),
                    resume_ticks=result.get("resume_ticks", 0),
                    audio_stream_index=result.get("audio_stream_index"),
                    subtitle_stream_index=result.get("subtitle_stream_index"),
                )
            except Exception as exc:  # noqa: BLE001 - surface playback failures, don't crash the addon
                xbmcgui.Dialog().notification("Jellyfin", f"Playback failed: {exc}")
                status, played_item_id = None, None
            if status == "ended" and result.get("item_type") == "Episode":
                _offer_next_episode(client, played_item_id)
            # Loop back to the detail page (e.g. to show updated resume state).
        elif result["action"] == "open":
            # A "More Like This" item was clicked - opens on top, and
            # backing out of it re-shows this same detail page (the
            # while-loop reopening DetailWindow again), the same nesting
            # pattern _browse_loop/_search_loop use for their own items.
            _open_item(client, result["item_id"], result["item_type"], result["item_name"],
                       item_overview=result.get("item_overview", ""))


def _open_item(client, item_id, item_type, item_name, item_overview=""):
    if item_type in CONTAINER_TYPES:
        _browse_loop(client, item_id, item_name, parent_item_type=item_type,
                     parent_overview=item_overview)
    else:
        _detail_loop(client, item_id)


def _browse_loop(client, parent_id, title, parent_item_type=None, parent_overview=""):
    # Remembers which item was last opened from this screen so that, when
    # BrowseWindow.open() runs again after Back, it re-selects that same
    # item instead of resetting focus to the top of the list.
    select_item_id = None
    while True:
        result = BrowseWindow.open(
            ADDON_PATH, client=client, parent_id=parent_id, title=title,
            parent_item_type=parent_item_type, select_item_id=select_item_id,
            parent_overview=parent_overview,
        )
        if not result:
            return
        if result["action"] == "open":
            select_item_id = result["item_id"]
            _open_item(client, result["item_id"], result["item_type"], result["item_name"],
                       item_overview=result.get("item_overview", ""))
        elif result["action"] == "play_queue":
            try:
                player.play_queue(client, result["item_ids"], item_type=result.get("item_type"))
            except Exception as exc:  # noqa: BLE001 - surface playback failures, don't crash the addon
                xbmcgui.Dialog().notification("Jellyfin", f"Playback failed: {exc}")


def _search_loop(client):
    while True:
        result = SearchWindow.open(ADDON_PATH, client=client)
        if not result:
            return
        if result["action"] == "open":
            _open_item(client, result["item_id"], result["item_type"], result["item_name"],
                       item_overview=result.get("item_overview", ""))


def _confirm_quit():
    return xbmcgui.Dialog().yesno("Jellyfin", "Quit and return to Kodi?")


def _home_loop(client):
    """Runs Home for one server session. Returns a new client to switch the
    active server to, or None once the user backs all the way out."""
    # Remembers which hub-row tile was last opened so that, when
    # HomeWindow.open() runs again after Back, it re-selects that same tile
    # instead of resetting focus to the Libraries row.
    select_control_id = None
    select_item_id = None
    while True:
        # Belt-and-suspenders: also bail before even trying to (re)open
        # Home, not just after - Kodi refuses to construct any new window
        # once it's begun tearing down for shutdown ("maximum number of
        # windows reached"), so re-entering the loop with abort already
        # signalled must never reach HomeWindow.open() again.
        if xbmc.Monitor().abortRequested():
            return None
        result = HomeWindow.open(
            ADDON_PATH, client=client,
            select_control_id=select_control_id, select_item_id=select_item_id,
        )
        if not result:
            # Kodi force-closes any open window and expects the script to
            # exit promptly on shutdown - popping a confirmation dialog here
            # would sit forever waiting for a click that will never come
            # (no one's driving the UI during shutdown), which is exactly
            # what made this loop miss Kodi's 5-second "stop the script"
            # grace period and get killed instead of exiting cleanly.
            if xbmc.Monitor().abortRequested():
                return None
            confirmed = _confirm_quit()
            # Re-check after the dialog, not just before it: Kodi can force
            # the yesno() dialog closed mid-shutdown and hand back a falsy
            # result (as if the user picked "No") with abort now signalled -
            # looping back into HomeWindow.open() at that point is exactly
            # what crashed with "maximum number of windows reached" on a
            # real device (Kodi already mid-teardown, refusing new windows).
            if confirmed or xbmc.Monitor().abortRequested():
                return None
            continue
        if result["action"] == "browse":
            select_control_id = result["control_id"]
            select_item_id = result["item_id"]
            _browse_loop(client, result["library_id"], result["library_name"])
        elif result["action"] == "open":
            select_control_id = result["control_id"]
            select_item_id = result["item_id"]
            _open_item(client, result["item_id"], result["item_type"], result["item_name"],
                       item_overview=result.get("item_overview", ""))
        elif result["action"] == "search":
            _search_loop(client)
        elif result["action"] == "servers":
            new_client = _manage_servers(client)
            if new_client is not None:
                return new_client


def _take_over_running_slot(home_window):
    """A previous instance is still marked running - ask it to stop
    (STOP_REQUESTED_PROPERTY) rather than just refusing to start, and wait
    up to STOP_WAIT_TIMEOUT_SECONDS for it to notice and free the slot
    itself. If it doesn't (genuinely wedged, e.g. blocked inside a Kodi
    engine call our own code can't preempt), reclaim the slot anyway -
    leaving the old instance's window loop to exit into a no-op the next
    time it wakes up is far better than every future launch attempt being
    refused forever."""
    xbmc.log(
        f"{LOG_PREFIX} Already running in another instance - asking it to "
        "stop and taking over",
        xbmc.LOGWARNING,
    )
    home_window.setProperty(STOP_REQUESTED_PROPERTY, "true")
    monitor = xbmc.Monitor()
    waited = 0.0
    while home_window.getProperty(RUNNING_PROPERTY) == "true" and waited < STOP_WAIT_TIMEOUT_SECONDS:
        if monitor.waitForAbort(0.5):
            home_window.clearProperty(STOP_REQUESTED_PROPERTY)
            return False
        waited += 0.5
    home_window.clearProperty(STOP_REQUESTED_PROPERTY)
    if home_window.getProperty(RUNNING_PROPERTY) == "true":
        xbmc.log(
            f"{LOG_PREFIX} Previous instance did not stop within "
            f"{STOP_WAIT_TIMEOUT_SECONDS}s - reclaiming the running slot anyway",
            xbmc.LOGWARNING,
        )
    return True


def run():
    home_window = xbmcgui.Window(HOME_WINDOW_ID)
    if home_window.getProperty(RUNNING_PROPERTY) == "true":
        if not _take_over_running_slot(home_window):
            return
    home_window.setProperty(RUNNING_PROPERTY, "true")
    try:
        _migrate_legacy_settings()
        client = _load_saved_client()
        if not client:
            client = _login()
        while client:
            try:
                client = _home_loop(client)
            except ScriptStopRequested:
                # A newer launch is taking over this instance's slot (see
                # _take_over_running_slot) - exit cleanly rather than
                # reopening Home, the same way the shutdown-abort
                # RuntimeError below is handled.
                break
            except RuntimeError:
                # WindowXML/Dialog construction can raise "maximum number
                # of windows reached" if Kodi has begun tearing down for
                # shutdown right as a window loop tries to (re)open one -
                # see lib/windows/kodigui.py's open() docstring for why
                # this is caught exactly once here rather than swallowed
                # and retried closer to the source (that caused an
                # infinite retry loop on a real device). Only treat it as
                # a clean shutdown if Kodi is actually aborting; a genuine
                # bug elsewhere should still surface.
                if not xbmc.Monitor().abortRequested():
                    raise
                break
    finally:
        # Always clears, even on an unhandled exception - a permanent
        # lockout after a crash would be worse than the bug this guards
        # against.
        home_window.clearProperty(RUNNING_PROPERTY)
